import React from "react"
import logo from '../assets/logo.png'
import { useState } from "react"
import BottomMenu from "../components/BottomMenu";
import { Button } from "@mui/material";

function HomePage(){

    const [isPatched, setIsPatched] = useState(false);

    return(
        <div>

            <Button variant="contained" onClick={function(){
                chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                    alert('found tab: ' + tabs[0].id)
                    chrome.tabs.sendMessage(tabs[0].id, { command: 'patch'}, (response) =>{
                        setIsPatched(true);

                    })
                });
            }}>
                patch
            </Button>

            {isPatched && <h3>PATCHED</h3>}

        </div>
    )
}

export default HomePage