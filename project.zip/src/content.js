chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.command === "patch") {
    console.log("📨 Forwarding patch command to page context...");
    window.postMessage({ type: "MONKEY_PATCH_GFORM" }, "*");
    sendResponse({ status: "forwarded to page" });
    return true;
  }
});

// Inject your script
function injectScript(file) {
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL(file);
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
}

console.log('Injecting inject.js');
injectScript("inject.js");