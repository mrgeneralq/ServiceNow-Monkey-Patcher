import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import BottomMenu from './components/BottomMenu'
import { Outlet } from 'react-router-dom'
import { Grid } from '@mui/material'

function App() {
  return (
    <Grid container rowSpacing={1}>
      <Grid size={12} height={250}>
        <Outlet/>
      </Grid>
      <Grid size={12}>
        <BottomMenu/>
      </Grid>
    </Grid>
  )
}

export default App
