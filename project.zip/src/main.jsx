import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createHashRouter, RouterProvider} from 'react-router-dom'
import HomePage from './pages/HomePage.jsx'
import NotFoundPage from './pages/NotFoundPage.jsx'
import App from './App.jsx'
import AboutPage from './pages/AboutPage.jsx'
import { ThemeProvider, createTheme } from '@mui/material'
import AppTheme from './themes/AppTheme.js'

const router = createHashRouter([
  {
    path: '/',
    element: <App/>,
    errorElement: <NotFoundPage/>,
    children: [
        {index: true, element: <HomePage/>},
        {path: 'about', element: <AboutPage/>}
    ]
  }
]);


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ThemeProvider theme={AppTheme}>
      <RouterProvider router={router} />
    </ThemeProvider>
  </StrictMode>,
)
